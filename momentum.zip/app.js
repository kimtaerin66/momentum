const loginForm = document.querySelector("#login-form");
const loginInput = document.querySelector("#login-form input");
const loginButton = document.querySelector("#login-form button");
const greeting = document.querySelector("#greeting");

const USERNAME_KEY = "username";

function onLoginSubmit(e){
    e.preventDefault(); 
    loginForm.classList.add("hidden")
    const username = loginInput.value;
    localStorage.setItem("USERNAME_KEY", username)
    paintGreetings (username);

}

function paintGreetings (username) {
    greeting.innerHTML = `Hello ${username}`;
    greeting.classList.remove("hidden");
}

const savedUsername= localStorage.getItem("USERNAME_KEY");
if(savedUsername === null) {
    loginForm.classList.remove("hidden");
    loginForm.addEventListener("submit", onLoginSubmit);
} else {
    paintGreetings(savedUsername);
   
}